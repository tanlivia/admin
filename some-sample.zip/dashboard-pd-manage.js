'use strict';


angular.module('ShopsgramWebApp').controller('DashboardPdManageCtrl', ['$scope', '$routeParams', '$location', '$http', 'parse', 'analytics', function($scope, $routeParams, $location, $http, parse, analytics) {
  $scope.products = [];
  $scope.newNewArrivals = [];
  $scope.newNewRecommended = [];
//  $scope.newNewSpecial = [];
  $scope.productsEmpty = false;
  $scope.productsLoaded = false;

  $scope.productsCount = 0;
  $scope.productsCountPerPage = 5;
  $scope.paginationDisplayNumber = 7;

  $scope.options = {
    page: $routeParams.p-0
  };
  if (!$scope.options.page) $scope.options.page = 1;

  $scope.initialize = function() {
    $scope.updateProducts();
  };

  $scope.updateProducts = function() {
    var options = {
      includeShop: true,
      inShops: [$routeParams.id],
      showPrivate: true,
      limit: $scope.productsCountPerPage,
      skip: ($scope.options.page - 1) * $scope.productsCountPerPage
    }

    options.count = true;
    parse.getProductCollection(options, {
      success: function(count) {
        $scope.productsCount = count;
        $scope.pagination = $scope.generatePagination(
            Math.ceil(count/$scope.productsCountPerPage),
            $scope.options.page,
            {displayNumber: $scope.paginationDisplayNumber});
        $scope.safeApply();
      },
      error: function() {}
    });

    delete options.count;
    parse.getProductCollection(options, {
      success: function(results) {
        console.log("retrieve " + results.length + " posts");
        $scope.products = results;
        $scope.productsLoaded = true;
        if($scope.products.length == 0) {
          $scope.productsEmpty = true;
        }
        $scope.newNewArrivals = _.map($scope.products, function(obj) {
          return obj.get('newArrival');
        });
        $scope.newNewRecommended = _.map($scope.products, function(obj) {
          return obj.get('recommended');
        });
        $scope.$apply()
      },
      error: function(error) {
        $scope.productsLoaded = true;
        console.log(error)
      }
    });
  };

  $scope.changeFeature = function(type, idx, value) {
    var product = $scope.products[idx];
    product.set(type, value);
    product.save();
  };

  $scope.deleteProduct = function(product) {
    parse.deleteProduct(product, {
      success: function() {
        var deletedIndex = "";
        _.each($scope.products, function(element, index, list) {
          if(element.id == product.id) {
            deletedIndex = index;
          }
        });
        $scope.products.splice(deletedIndex, 1);
        $scope.$apply();
      }
    })
  };

  $scope.uploadProductBtnClicked = function() {
    analytics.btnClickEvent({
      'page': $location.url(),
      'eventLabel': 'open-new-product'
    }, {}, {});

    $location.path('/dashboard/post/' + $scope.shop.id).search({});
  };

  $scope.pageIndexClicked = function(pageIndex) {
    if ($scope.options.page === pageIndex) return;
    if (pageIndex >= 1 && pageIndex <= Math.ceil($scope.productsCount/$scope.productsCountPerPage)) {
      $location.search('p', pageIndex);
    }
  };

  $scope.getDisabledClass = function(key) {
    if (key === 'previous' && $scope.options.page === 1) {
      return 'disabled';
    } else if (key === 'next' && $scope.options.page === Math.ceil($scope.productsCount/$scope.productsCountPerPage)) {
      return 'disabled';
    }
    return '';
  };

  $scope.getActiveClass = function(page) {
    if (page === $scope.options.page) {
      return 'active';
    } else {
      return '';
    }
  };

}]);