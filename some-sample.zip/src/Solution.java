
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class Solution {
    // Method 1: Time Complexity: O(n^2); 
    static public int lowestCommonAncestor1(TreeNode root, int d1, int d2) {
        if(root == null) return -1;
        if(root.val == d1 || root.val == d2) return root.val;
        int matches = countMatches(root.left, d1, d2);
        // Moving to right if we can't find any matches in left subtree;
        if(matches == 0) return lowestCommonAncestor1(root.right, d1, d2);
        // Moving to left subtree if we find d1 d2 are all in left;
        else if(matches == 2) return lowestCommonAncestor1(root.left, d1, d2);
        // Return current value since we find one matches in left(another matches will in right.)
        else return root.val;
    }
    static public int countMatches(TreeNode root, int d1, int d2) {
        if(root == null) return 0;
        int matches = countMatches(root.left, d1, d2) + countMatches(root.right, d1, d2);
        if(root.val == d1 || root.val == d2) return matches + 1;

        return matches;
    }
    
    // Method 2: Time Complexity: O(n);
    static public int lowestCommonAncestor2(TreeNode root, int d1, int d2) {
        if(root == null) return -1;
        int[] in = inorder(root);
        int[] post = postorder(root);
        System.out.println("inorder: " + Arrays.toString(in));
        System.out.println("postorder: " + Arrays.toString(post));
        // Convert aray to Hashtable in order to get index in O(1) time complexity.
        Hashtable<Integer, Integer> inHash = new Hashtable<Integer, Integer>();
        Hashtable<Integer, Integer> postHash = new Hashtable<Integer, Integer>();
        for(int i = 0; i < post.length; i++) {
            inHash.put(in[i], i);
            postHash.put(post[i], i);
        }
        // The ancestor must in between inorder[d1] and inorder[d2] based on inorder concept.
        int start = Math.min(inHash.get(d1), inHash.get(d2));
        int end = Math.max(inHash.get(d1), inHash.get(d2));
        int res = 0;
        // The ancestor's position will be in the right of postorder[d2], which is the maximum reaching index.
        for(int i = start; i <= end; i++) {
            res = Math.max(res, postHash.get(in[i]));
        }
        return post[res];
    }
    // In order to minimize the overhead, using stack here instead of recursive;
    static public int[] inorder(TreeNode root) {
        ArrayList<Integer> content = new ArrayList<Integer>();
        Stack<TreeNode> nodes = new Stack<TreeNode>();
        TreeNode current = root;
        while(!nodes.empty() || current != null) {
            if(current != null) {
                nodes.push(current);
                current = current.left;
            } else {
                current = nodes.peek();
                content.add(current.val);
                nodes.pop();
                current = current.right;
            }
        }
        return convertIntegers(content);
    }
    static public int[] postorder(TreeNode root) {
        ArrayList<Integer> content = new ArrayList<Integer>();
        Stack<TreeNode> s1 = new Stack<TreeNode>();
        Stack<TreeNode> s2 = new Stack<TreeNode>();
        s1.push(root);
        while (!s1.empty()) {
            TreeNode current = s1.pop();
            s2.push(current);
            if(current.left != null) s1.push(current.left);
            if(current.right != null) s1.push(current.right);
        }

        while (!s2.empty()) {
            content.add(s2.pop().val);
        }
        return convertIntegers(content);
    }
    
    static public int[] convertIntegers(ArrayList<Integer> list) {
        int[] res = new int[list.size()];
        int i = 0;
        for(Integer l : list) {
            res[i++] = l;
        }
        return res;
    }
    // Method 3: Time Complexity: O(n);
    static public int lowestCommonAncestor3(TreeNode root, int d1, int d2) {
        if(root == null) return -1;
        if(root.val == d1 || root.val == d2) return root.val;
        int left = lowestCommonAncestor3(root.left, d1, d2);
        int right = lowestCommonAncestor3(root.right, d1, d2);
        // Return current value if we find one match in left, one in right;
        if(left != -1 && right != -1) return root.val;
        // Moving to left if we find more than one match in left, otherwise, go right.
        return (left != -1)? left : right;
    }
    
    static public void main(String[] args) {
        int mode = 1;  // default mode is 1
        String treeString = "";
        int d1 = 0;
        int d2 = 0;
        System.out.println("Parsing args...");
        for (int i = args.length - 1; i >= 0 ; i--) {
            //System.out.println("[" + i + "]" + args[i]);
            if (args[i].equals("-m") && i + 1 < args.length) {
                mode = Integer.parseInt(args[i+1]);
            }
            if (args[i].equals("-a") && i + 1 < args.length) {
                treeString = args[i+1];
            }
            if (args[i].equals("-d1") && i + 1 < args.length) {
                d1 = Integer.parseInt(args[i+1]);
            }
            if (args[i].equals("-d2") && i + 1 < args.length) {
                d2 = Integer.parseInt(args[i+1]);
            }
        }
        
        System.out.println("Finish parsing args. mode=" + mode + " treeString=[" + treeString + "]");
        System.out.println("Creating tree...");
        
        TreeNode tree = createTree(treeString);
        //printLevelOrder(tree);
        
        System.out.println("Run Algorithem...");
        int res = 0;
        switch(mode) {
            case 1: res = lowestCommonAncestor1(tree, d1, d2); break;
            case 2: res = lowestCommonAncestor2(tree, d1, d2); break;
            case 3: res = lowestCommonAncestor3(tree, d1, d2); break;
        }
        System.out.println("The lowest Common Ancestor for " + d1 + " and " + d2 + " is: " + res);
    }
    
    static public TreeNode createTree(String treeString) {
        if (treeString == null || treeString.equals("")) {
            return null;
        }
        
        String[] nodeStrings = treeString.split(",");
        if (nodeStrings.length == 0 || nodeStrings[0].equals("#")) return null;
        
        int length = nodeStrings.length;
        TreeNode root = new TreeNode(Integer.parseInt(nodeStrings[0]));
        Queue<TreeNode> q = new LinkedList<TreeNode>();
        q.add(root);
        
        int index = 1;
        while(!q.isEmpty() && index < length) {
            TreeNode node = q.poll();
            
            if (!nodeStrings[index].equals("#")) {
                node.left = new TreeNode(Integer.parseInt(nodeStrings[index]));
                q.add(node.left);
            }
            index ++;
            
            if (index < length && !nodeStrings[index].equals("#")) {
                node.right = new TreeNode(Integer.parseInt(nodeStrings[index]));
                q.add(node.right);
            }
            index ++;
        }
        return root;
    }
    
    
    static public void printLevelOrder(TreeNode root) {
        if(root == null) {System.out.println("Blank Tree!"); return ;}

        Queue<TreeNode> q = new LinkedList<TreeNode>();
        q.add(root);
        int nodesInCurrentLevel = 1;
        int nodesInNextLevel = 0;
        while(!q.isEmpty()) {
            TreeNode t = q.peek();
            if(t.left != null) {
                q.add(t.left);
                nodesInNextLevel ++;
            }
            if(t.right != null) {
                q.add(t.right);
                nodesInNextLevel ++;
            }
            System.out.print(t.val + " ");
            q.remove();
            nodesInCurrentLevel --;
            if(nodesInCurrentLevel == 0) {
                nodesInCurrentLevel = nodesInNextLevel;
                nodesInNextLevel = 0;
                System.out.println();
            }
        }
    }
}
