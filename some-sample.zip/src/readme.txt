API to run solution.java:
-m: select which mode(method) you want to check. You can type 1, 2, or 3. 
-a: array for building tree. Using comma to separate, NO space. "#" represent the node is "null".
-d1: the first digit you want to check.
-d2: the second digit you want to check.

For example:
(1)-m 2 -a 1,2,3,4,#,5,6,#,8,9,#,7 -d1 4 -d2 5 
After parsing, you will get:
Finish parsing args. mode=2 treeString=[1,2,3,4,#,5,6,#,8,9,#,7] 
The lowest Common Ancestor for 4 and 5 is: 1

(2)-m 2 -a 1,2,3,4,#,5,6 -d1 6 -d2 5
Finish parsing args. mode=3 treeString=[1,2,3,4,#,5,6]
The lowest Common Ancestor for 6 and 5 is: 3
